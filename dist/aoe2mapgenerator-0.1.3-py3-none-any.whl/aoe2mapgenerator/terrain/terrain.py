

def terrain():
    """
    TODO
    """
    return