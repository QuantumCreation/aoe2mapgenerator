from setuptools import setup, find_packages

setup(
    name="aoe2mapgenerator",
    version="0.1",
    packages=find_packages(),
    author="Joseph Hayden",
    author_email="joseph6433@gmail.com",
    description="A short description of your package",
    install_requires=[],
)